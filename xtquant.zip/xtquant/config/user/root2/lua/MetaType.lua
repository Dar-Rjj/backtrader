--------------------------------------------------------------
-- lua与C++兼容的常量定义，常量值目前为"MetaId_FieldId"
-- @author zhangjin
-- @since 2012-7-17
---------------------------------------------------------------

--K线
META_FIELD_KLINE_HIGH_PRICE = "1001_1"					--最高价
META_FIELD_KLINE_LOW_PRICE = "1001_2"					--最低价
META_FIELD_KLINE_CLOSE_PRICE = "1001_3"					--收盘价